package com.mindtree.kalingahospital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KalingahospitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
