package com.mindtree.kalingahospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KalingahospitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(KalingahospitalApplication.class, args);
	}

}
